---
name: qualita-branding
description: "Aplica el criterio de Qualita Studio para proyectos de branding: armado y revisión de manuales de marca, identidad visual y lineamientos para redes y pauta. Sirve para crear, ampliar o auditar un manual de marca, sumar una sección de pauta o contenido pago, definir zonas seguras de historias orgánicas y pagas, jerarquía de subtítulos y textos superpuestos, filtros de foto, carruseles y uso de recursos gráficos según soporte. También sirve para bajar el manual a briefs o guiones de producción, pedir material al cliente o planificar plazos de un proyecto de marca. Usala cuando aparezcan pedidos como manual de marca, brandbook, guía de estilo, lineamientos de pauta, zona segura, recursos gráficos, identidad visual o cronograma de branding."
---

# Criterio de Qualita: Branding

Esta skill reúne cómo trabaja Qualita los proyectos de marca, sobre todo el manual. La idea es que el manual sirva para producir piezas reales, incluido el contenido pago, y que no sea solo una presentación de la identidad. Usala para armar, ampliar o revisar manuales y para planificar los tiempos de un proyecto de branding.

## Cómo trabajamos

### El manual como base digital
- Tratá el manual como un documento digital que ya cubre redes sociales, subtítulos, títulos y zonas seguras. Esa es la base sobre la que se construye todo lo demás.
- Sumá los lineamientos de pauta como una capa adicional sobre esa base, sin reemplazarla. Lo orgánico sigue vigente y la pauta lo complementa.

### Lineamientos para pauta
- Incluí siempre lineamientos específicos para formatos de pauta: subtítulos, carruseles, zonas seguras, jerarquía de textos superpuestos, filtros de foto y qué recursos gráficos sirven para pauta. Si faltan, el manual no guía la producción de contenido pago y aparecen malentendidos.
- Escribí los lineamientos para corregir lo que hace mala una pieza. Resolvé de forma explícita la jerarquía de subtítulos y textos, y el uso de los filtros de foto del manual en los videos. Son los errores más comunes de los clientes.
- Diferenciá la zona segura de las historias pagas de la de las orgánicas. La paga tiene más margen, por ejemplo por el espacio del link.
- Tomá como referencia las medidas de zona segura que publica Meta, para no inventarlas y apoyarte en la fuente oficial.

### Recursos gráficos y soportes
- Aclarás para qué soporte sirve cada recurso gráfico: impresión, piezas físicas, historias, pauta, etc. Si no lo aclarás, se terminan usando en digital recursos pensados para impresión estática.
- Revisá con especial cuidado los manuales antiguos, anteriores al método actual o pensados para piezas físicas. Son los que más se prestan a usos equivocados en redes.

### Del manual a la producción
- Usá los lineamientos de foto y las referencias visuales del manual para guiar los guiones o briefs de producción de contenido para pauta. Así la producción sale alineada con la marca desde el inicio.
- Apoyate en esos mismos lineamientos para definir el material que se le pide al cliente. Si el pedido es claro, el material llega utilizable.

### Cómo ampliar el manual
- Antes de sumar una sección nueva, armá la lista concreta de puntos que hay que definir por marca. Eso evita una exploración abierta que no cierra.

### Plazos
- Al fijar plazos, considerá la duración del proyecto y los clientes simultáneos. Si adelantás plazos, se achican los días disponibles para el manual.
- No apures el cronograma sin necesidad. El primer recortado suele ser el manual, que es lo que después guía todo.

## Antes de entregar

- [ ] El manual mantiene la base digital: redes sociales, subtítulos, títulos y zonas seguras.
- [ ] Tiene la capa de pauta: subtítulos, carruseles, zonas seguras, jerarquía de textos superpuestos, filtros de foto y recursos gráficos aptos para pauta.
- [ ] Resuelve explícitamente la jerarquía de subtítulos y textos, y los filtros de foto en video.
- [ ] Diferencia la zona segura de historias pagas y orgánicas, con las medidas de Meta como referencia.
- [ ] Cada recurso gráfico indica para qué soporte sirve.
- [ ] Los lineamientos de foto y las referencias visuales alcanzan para armar briefs o guiones y para pedirle material al cliente.
- [ ] Toda sección nueva partió de una lista concreta de puntos a definir por marca.
- [ ] El cronograma deja tiempo real para el manual, teniendo en cuenta la duración del proyecto y los clientes simultáneos.

## Cuando hay dudas

Preguntate si el manual le alcanza a alguien que tiene que producir una pieza concreta, orgánica o paga, sin pedir aclaraciones. Si la respuesta es no, falta definir algo.

Preferí reglas explícitas y prácticas antes que lineamientos abiertos. Definí primero qué hay que resolver.

Cuidá el tiempo del manual, porque es lo que evita errores en la producción.